CREATE DATABASE DHarbour_DBProject

USE DHarbour_DBProject

CREATE TABLE Customer
(
	CustID CHAR (6) PRIMARY KEY NOT NULL,
	CustName VARCHAR (50) NOT NULL,
	CustPhone VARCHAR (12) NOT NULL,
	CustAddr VARCHAR (60) NOT NULL,
	CustGen VARCHAR (7) NOT NULL,
	CustEmail VARCHAR (30) NOT NULL,
	
	CONSTRAINT CheckCustID
		CHECK (CustID LIKE 'CS[0-9][0-9][0-9]'),
	CONSTRAINT CheckCustName
		CHECK (CustName LIKE 'Mr. %' OR CustName LIKE 'Mrs. %'),
	CONSTRAINT CheckCustAddr
		CHECK (CustAddr LIKE '% street' OR CustAddr LIKE '% road'),
	CONSTRAINT CheckCustGen
		CHECK (CustGen IN ('Male','Female'))
)

CREATE TABLE Staff
(
	StaffID CHAR (6) PRIMARY KEY NOT NULL,
	StaffName VARCHAR (50) NOT NULL,
	StaffPhone VARCHAR (12) NOT NULL,
	StaffAddr VARCHAR (60) NOT NULL,
	StaffGen VARCHAR (7) NOT NULL,
	StaffEmail VARCHAR (30) NOT NULL,
	StaffSal INT NOT NULL,

	CONSTRAINT CheckStaffID
		CHECK (StaffID LIKE 'ST[0-9][0-9][0-9]'),
	CONSTRAINT CheckStaffName
		CHECK (StaffName LIKE 'Mr. %' OR StaffName LIKE 'Mrs. %'),
	CONSTRAINT CStaffName
		CHECK (Len(StaffName)>3),
	CONSTRAINT CheckStaffAddr
		CHECK (StaffAddr LIKE '% street' OR StaffAddr LIKE '% road'),
	CONSTRAINT CheckStaffGen
		CHECK (StaffGen IN ('Male','Female')),
)

CREATE TABLE BoatType
(
	BoatTypeID CHAR (6) PRIMARY KEY NOT NULL,
	BoatTypeName VARCHAR (30) NOT NULL,

	CONSTRAINT CheckBoatTID
		CHECK (BoatTypeID LIKE 'BT[0-9][0-9][0-9]'),
	CONSTRAINT CBoatTID
		CHECK (len(BoatTypeName)>5)
)

CREATE TABLE Boat
(
	BoatID CHAR (6) PRIMARY KEY NOT NULL,
	BoatTypeID CHAR (6) REFERENCES BoatType(BoatTypeID) ON DELETE CASCADE ON UPDATE CASCADE, 
	BoatName VARCHAR (30) NOT NULL,
	BoatRentPrice INT NOT NULL,
	BoatPurPrice INT NOT NULL,

	CONSTRAINT CheckBoatID
		CHECK (BoatID LIKE 'BO[0-9][0-9][0-9]')
)


CREATE TABLE Supplier
(
	SuppID CHAR (6) PRIMARY KEY NOT NULL,
	SuppName VARCHAR (50) NOT NULL,
	SuppPhone VARCHAR (12) NOT NULL,
	SuppAddr VARCHAR (60) NOT NULL,
	SuppGen VARCHAR (7) NOT NULL,
	SuppEmail VARCHAR (30) NOT NULL,
	SuppSal INT NOT NULL,

	CONSTRAINT CheckSuppID
		CHECK (SuppID LIKE 'SP[0-9][0-9][0-9]'),
	CONSTRAINT CheckSuppName
		CHECK (SuppName LIKE 'Mr. %' OR SuppName LIKE 'Mrs. %'),
	CONSTRAINT CheckSuppAddr
		CHECK (SuppAddr LIKE '% street' OR SuppAddr LIKE '% road'),
	CONSTRAINT CheckSuppGen
		CHECK (SuppGen IN ('Male','Female')),
)

CREATE TABLE RentTransaction
(
	RentTrID CHAR (6) PRIMARY KEY NOT NULL,
	StaffID CHAR (6) REFERENCES Staff(StaffID) ON DELETE CASCADE ON UPDATE CASCADE,
	CustID CHAR (6)REFERENCES Customer(CustID) ON DELETE CASCADE ON UPDATE CASCADE,
	RentTransDate DATETIME NOT NULL,
	CONSTRAINT CheckRentID
		CHECK (RentTrID LIKE 'TR[0-9][0-9][0-9]'),
	CONSTRAINT CheckRentDate
		CHECK ((DATENAME(HOUR,RentTransDate)>= 9 AND DATENAME(HOUR,RentTransDate) < 15)OR(DATENAME(HOUR,RentTransDate)= 15 AND DATENAME(MINUTE,RentTransDate) = 0 AND DATENAME(SECOND,RentTransDate)=0))
)



CREATE TABLE RentDetail
(
	RentTrID CHAR (6) NOT NULL REFERENCES RentTransaction(RentTrID) ON DELETE CASCADE ON UPDATE CASCADE,
	BoatID CHAR (6) NOT NULL REFERENCES Boat(BoatID) ON DELETE CASCADE ON UPDATE CASCADE,
	DurRentBoat INT NOT NULL,

	CONSTRAINT PrimaryKeys PRIMARY KEY (RentTrID, BoatID)
)



CREATE TABLE PurchaseTransaction
(
	PurchaseTrID CHAR (6) PRIMARY KEY NOT NULL,
	StaffID CHAR (6) REFERENCES Staff(StaffID) ON DELETE CASCADE ON UPDATE CASCADE,
	SuppID CHAR (6) REFERENCES Supplier(SuppID) ON DELETE CASCADE ON UPDATE CASCADE,
	PurTransDate DATETIME NOT NULL,

	CONSTRAINT CheckPurID
		CHECK (PurchaseTrID LIKE 'TP[0-9][0-9][0-9]'),
	CONSTRAINT CheckPurDate
		CHECK ((DATENAME(HOUR,PurTransDate)>= 9 AND DATENAME(HOUR,PurTransDate) < 15)OR(DATENAME(HOUR,PurTransDate)= 15 AND DATENAME(MINUTE,PurTransDate) = 0 AND DATENAME(SECOND,PurTransDate)=0))
)



CREATE TABLE PurchaseDetail
(
	PurchaseTrID CHAR (6) NOT NULL REFERENCES PurchaseTransaction(PurchaseTrID) ON DELETE CASCADE ON UPDATE CASCADE,
	BoatID CHAR (6) NOT NULL REFERENCES Boat(BoatID) ON DELETE CASCADE ON UPDATE CASCADE,
	QtyPurBoat INT NOT NULL,

	CONSTRAINT Primarykeyss PRIMARY KEY (PurchaseTrID, BoatID)
)


