USE DHarbour_DBProject

--Customer


INSERT INTO Customer
VALUES ('CS001','Mr. Absal','081212939233','Bagong VI num. 6 street','Male','Absalasba@gmail.com')

INSERT INTO Customer
VALUES ('CS002','Mr. Ade','085799032120','Patrick XI num. 3 street','Male','Adedade@gmail.com')

INSERT INTO Customer
VALUES ('CS003','Mr. Albert','082111939699','Petruk VIII num. 9 street','Male','Albertrebla@yahoo.co.id')

INSERT INTO Customer
VALUES ('CS004','Mr. Aldo','089812428208','Spongebob XII num. 1 road','Male','AldoWidoyo@gmail.com')

INSERT INTO Customer
VALUES ('CS005','Mr. Joko','087899887766','Negara I num. 1 street','Male','WokoWijodo@yahoo.co.id')

INSERT INTO Customer
VALUES ('CS006','Mrs. Ferren','089559559977','Unicorn IX num. 1 street','Female','MFTFerren@gmail.com')

INSERT INTO Customer
VALUES ('CS007','Mrs. Bella','081122334455','Bagong XV num. 15 street','Female','Bellabell@gmail.co.id')

INSERT INTO Customer
VALUES ('CS008','Mrs. Angel','089988713525','Mekong XXI num. 21 street','Female','SpeakingAngela@gmail.com')

INSERT INTO Customer
VALUES ('CS009','Mrs. Olina','083125256345','Petruk XXX num. 1 road','Female','Olinaaaaaaaaanj@yahoo.co.id')

INSERT INTO Customer
VALUES ('CS010','Mrs. Dina','089182736455','Bagong VII num. 6 street','Female','FloriDina@gmail.com')


--Staff


INSERT INTO Staff
VALUES ('ST001','Mr. Abdul','08129233518','Gembrot banget 3 Num. 10 street','Male','GembrotSiAbdul@gmail.co.id',3750000)

INSERT INTO Staff
VALUES ('ST002','Mr. Abdel','08212933815','Gendut aja Num. 21 road','Male','GaKurusAbdel@yahoo.co.id',4000000)

INSERT INTO Staff
VALUES ('ST003','Mr. Badui','081694887766','Gantang Abris Num. 15 street','Male','BaduiBadut@yahoo.com', 3800000)

INSERT INTO Staff
VALUES ('ST004','Mr. Ferry','081357892019','Bijiq Matahari 3 Num. 4 street','Male','Ferryque@yahoo.com',4250000)

INSERT INTO Staff
VALUES ('ST005','Mr. Randu Kalu','081823455432','Giga Mendung 10 Num. 100 road','Male','RanduKalduAyam@gmail.co.id',3550000)

INSERT INTO Staff
VALUES ('ST006','Mrs. Ayu','083827356412','Bagong VII Num . 8 street','Female','Ayukuya@gmail.co.id',3500000)

INSERT INTO Staff
VALUES ('ST007','Mrs. Ratna','083141516171','Mainhantam 3 Num. 10 road','Female','Ratnantar@yahoo.co.id',5500000)

INSERT INTO Staff
VALUES ('ST008','Mrs. Colie','081314151617','Sarjana Ejen Abal 1 Num. 19 street','Female','ColieMululu@gmail.co.id',3650000)

INSERT INTO Staff
VALUES ('ST009','Mrs. Diani','084536271809','Harvest Bijique 3 Num. 31 road','Female','DianiYayaSuaMi@gmail.com',4000000)

INSERT INTO Staff
VALUES ('ST010','Mrs. Eva','088899992425','MaryLand Parkway 10 Num. 2 street','Female','EvaPorateIon@gmail.com',3850000)


-- BoatType

INSERT INTO BoatType
VALUES('BT001','Barge B')

INSERT INTO BoatType
VALUES('BT002','Bass Boat')

INSERT INTO BoatType
VALUES('BT003','Bracera')

INSERT INTO BoatType
VALUES('BT004','Cruise Ship')

INSERT INTO BoatType
VALUES('BT005','Canoe C')

INSERT INTO BoatType
VALUES('BT006','Sub Marine')

INSERT INTO BoatType
VALUES('BT007','Fishing Boat')

INSERT INTO BoatType
VALUES('BT008','Gondola')

INSERT INTO BoatType
VALUES('BT009','Hover Craft')

INSERT INTO BoatType
VALUES('BT010','Pleasure Craft')

--		Boat

-- All Calculation Based On Dollar ($)


INSERT INTO Boat
VALUES ('BO001','BT001','Velocidrome',75000,375000)

INSERT INTO Boat
VALUES ('BO002','BT002','Khezu',6000,30000)

INSERT INTO Boat
VALUES ('BO003','BT003','Tigrex',35000,275000)

INSERT INTO Boat
VALUES ('BO004','BT004','Plesioth',2500000,12500000)

INSERT INTO Boat
VALUES ('BO005','BT005','Rathalos',150,750)

INSERT INTO Boat
VALUES ('BO006','BT006','Fatalis',25600000,128000000)
						   
INSERT INTO Boat		   
VALUES ('BO007','BT007','Hemitaur',2600,13000)
						  
INSERT INTO Boat		   
VALUES ('BO008','BT008','Kirin',3400,17000)
						   
INSERT INTO Boat		   
VALUES ('BO009','BT009','KushulaDaora',4400,22000)
						   
INSERT INTO Boat		   
VALUES ('BO010','BT010','NarugaKuruga',45000,225000)

--Supplier

INSERT INTO Supplier
VALUES ('SP001','Mr. Aldi','088239211234','Giga Mendung 1 Num. 99 road','Male','Aldidlaldi@gmail.co.id',3550000)

INSERT INTO Supplier
VALUES ('SP002','Mr. Adrian','080987654321','Maryland Parkway 3 Num. 9 road','Male','AdrianUnta@gmail.co.id',5500000)

INSERT INTO Supplier
VALUES ('SP003','Mr. Doom','089988998800','Giga Mendung 7 Num. 15 street','Male','DoomsDay@gmail.co.id',10000000)

INSERT INTO Supplier
VALUES ('SP004','Mr. Dread','085782927262','Bagong V Num. 10 street','Male','DreadOutBtcht@gmail.co.id',12000000)

INSERT INTO Supplier
VALUES ('SP005','Mr. Word','089989988341','Petruk IX Num. 1 street','Male','MicrosWordEh@gmail.co.id',35000000)

INSERT INTO Supplier
VALUES ('SP006','Mrs. Adinda','089698896431','Bagong VIII Num. 8 street','Female','aaaahhAdinda@gmail.co.id',25000000)

INSERT INTO Supplier
VALUES ('SP007','Mrs. Ayami','081575955585','Giga Mendung 10 VII Num. 15 street','Female','miAyami@gmail.com',5000000)

INSERT INTO Supplier
VALUES ('SP008','Mrs. Britney','082188459510','Maryland Parkway 10 Num. 99 road','Female','BritneySpark@gmail.com',7500000)

INSERT INTO Supplier
VALUES ('SP009','Mrs. Della','080099001200','Bagong IV Num. 4 street','Female','DellayTerus@gmail.co.id',12500000)

INSERT INTO Supplier
VALUES ('SP010','Mrs. Natasha','084443999821','Mainhantam 3 Num. 9 road','Female','Natashampah@gmail.co.id',15000000)

--RentTransaction

INSERT INTO RentTransaction	--  15
VALUES ('TR001','ST001','CS001','2019/01/01 09:01:02')  
							
INSERT INTO RentTransaction	--  14
VALUES ('TR002','ST002','CS001','2019/01/01 13:48:56')					
							
INSERT INTO RentTransaction	--  13
VALUES ('TR003','ST003','CS002','2019/01/01 14:30:12')					
							
INSERT INTO RentTransaction	--  12
VALUES ('TR004','ST004','CS007','2019/01/01 14:59:59')					
							
INSERT INTO RentTransaction	--  11
VALUES ('TR005','ST005','CS005','2019/01/02 09:45:50')					
							
INSERT INTO RentTransaction	--  10
VALUES ('TR006','ST006','CS008','2019/01/02 10:30:31')					
							
INSERT INTO RentTransaction	--  9
VALUES ('TR007','ST007','CS006','2019/01/02 13:39:57')					
							
INSERT INTO RentTransaction	--  8
VALUES ('TR008','ST008','CS009','2019/01/02 15:00:00')					
							
INSERT INTO RentTransaction	--  7
VALUES ('TR009','ST009','CS004','2019/01/05 12:00:55')					
							
INSERT INTO RentTransaction	--  6
VALUES ('TR010','ST010','CS004','2019/01/06 11:15:00')					
							
INSERT INTO RentTransaction	--  5
VALUES ('TR011','ST010','CS003','2019/01/06 12:30:00')					
							  
INSERT INTO RentTransaction	--  4
VALUES ('TR012','ST008','CS010','2019/01/07 13:50:59')					
							  
INSERT INTO RentTransaction	--  3
VALUES ('TR013','ST002','CS004','2019/01/07 14:34:21')					
							  
INSERT INTO RentTransaction	--  2
VALUES ('TR014','ST006','CS009','2019/01/08 12:00:00')					
							  
INSERT INTO RentTransaction	--  1
VALUES ('TR015','ST010','CS008','2019/01/08 15:00:01')					

--RentDetTrans

INSERT INTO RentDetail 
VALUES ('TR001','BO001',10)					  

INSERT INTO RentDetail 
VALUES ('TR001','BO007',15)					

INSERT INTO RentDetail 
VALUES ('TR001','BO010',7)

INSERT INTO RentDetail 
VALUES ('TR002','BO002',4)

INSERT INTO RentDetail --  11
VALUES ('TR002','BO001',5)				

INSERT INTO RentDetail --  10
VALUES ('TR003','BO003',6)				

INSERT INTO RentDetail --  9
VALUES ('TR003','BO002',7)				
							--  
INSERT INTO RentDetail	--  8
VALUES ('TR003','BO004',8)				
							--  
INSERT INTO RentDetail	--  7
VALUES ('TR004','BO005',4)				
							--  
INSERT INTO RentDetail	--  6
VALUES ('TR005','BO007',5)				
							--  
INSERT INTO RentDetail	--  5
VALUES ('TR006','BO008',7)				
							--  
INSERT INTO RentDetail	--  4
VALUES ('TR007','BO009',8)				
							--  
INSERT INTO RentDetail	--  3
VALUES ('TR007','BO009',7)				
							--  
INSERT INTO RentDetail	--  2
VALUES ('TR008','BO010',8)				
							--  
INSERT INTO RentDetail	--  1
VALUES ('TR009','BO004',9)				

INSERT INTO RentDetail --  10
VALUES ('TR010','BO004',3)				

INSERT INTO RentDetail --  9
VALUES ('TR011','BO002',6)				
							--  
INSERT INTO RentDetail	--  8
VALUES ('TR011','BO007',7)	

INSERT INTO RentDetail
VALUES ('TR011','BO008',4)				
							--  
INSERT INTO RentDetail	--  7
VALUES ('TR012','BO008',5)				
							--  
INSERT INTO RentDetail	--  6
VALUES ('TR013','BO003',2)				
							--  
INSERT INTO RentDetail	--  5
VALUES ('TR014','BO002',5)				
							--  
INSERT INTO RentDetail	--  4
VALUES ('TR015','BO003',8)				
							--  
INSERT INTO RentDetail	--  3
VALUES ('TR015','BO006',9)				
							--  
INSERT INTO RentDetail	--  2
VALUES ('TR015','BO007',10)				
							--  
INSERT INTO RentDetail	--  1
VALUES ('TR015','BO010',1)				

--PurchaseTransaction

INSERT INTO PurchaseTransaction --  15
VALUES ('TP001','ST001','SP001','2018/12/22 09:01:48')					

INSERT INTO PurchaseTransaction --  14
VALUES ('TP002','ST002','SP002','2018/12/22 09:04:49')					

INSERT INTO PurchaseTransaction --  13
VALUES ('TP003','ST003','SP003','2018/12/22 09:07:51')					

INSERT INTO PurchaseTransaction --  12
VALUES ('TP004','ST004','SP004','2018/12/22 13:05:55')					

INSERT INTO PurchaseTransaction --  11
VALUES ('TP005','ST005','SP005','2018/12/23 15:01:01')					

SELECT * FROM PurchaseTransaction

INSERT INTO PurchaseTransaction --  10
VALUES ('TP006','ST006','SP006','2018/12/24 10:05:07')					

INSERT INTO PurchaseTransaction --  9
VALUES ('TP007','ST007','SP007','2018/12/24 15:05:07')					
							--  
INSERT INTO PurchaseTransaction	--  8
VALUES ('TP008','ST008','SP008','2018/12/25 10:06:14')					
							--  
INSERT INTO PurchaseTransaction	--  7
VALUES ('TP009','ST009','SP009','2018/12/25 14:12:15')					
							--  
INSERT INTO PurchaseTransaction	--  6
VALUES ('TP010','ST010','SP010','2018/12/26 10:10:10')					
							--  
INSERT INTO PurchaseTransaction	--  5
VALUES ('TP011','ST009','SP008','2018/12/26 9:06:14')					
							--  
INSERT INTO PurchaseTransaction	--  4
VALUES ('TP012','ST008','SP009','2018/12/26 14:06:14')					
							--  
INSERT INTO PurchaseTransaction	--  3
VALUES ('TP013','ST007','SP006','2018/12/27 10:06:14')					
							--  
INSERT INTO PurchaseTransaction	--  2
VALUES ('TP014','ST006','SP007','2018/12/28 12:06:16')					
							--  
INSERT INTO PurchaseTransaction	--  1
VALUES ('TP015','ST010','SP010','2018/12/31 15:00:00')					

--PurDetTrans

INSERT INTO PurchaseDetail 
VALUES ('TP001','BO001',10)					

INSERT INTO PurchaseDetail --  14
VALUES ('TP001','BO007',10)					

INSERT INTO PurchaseDetail --  13
VALUES ('TP001','BO010',10)					

INSERT INTO PurchaseDetail --  12
VALUES ('TP002','BO002',10)					

INSERT INTO PurchaseDetail --  11
VALUES ('TP002','BO004',5)					

INSERT INTO PurchaseDetail --  10
VALUES ('TP003','BO007',7)					

INSERT INTO PurchaseDetail --  9
VALUES ('TP003','BO008',10)					
							--  
INSERT INTO PurchaseDetail	--  8
VALUES ('TP004','BO005',15)					
							--  
INSERT INTO PurchaseDetail	--  7
VALUES ('TP005','BO009',12)					
							--  
INSERT INTO PurchaseDetail	--  6
VALUES ('TP006','BO003',11)					
							--  
INSERT INTO PurchaseDetail	--  5
VALUES ('TP007','BO006',6)					
							--  
INSERT INTO PurchaseDetail	--  4
VALUES ('TP008','BO010',8)					
							--  
INSERT INTO PurchaseDetail	--  3
VALUES ('TP008','BO007',2)					
							--  
INSERT INTO PurchaseDetail	--  2
VALUES ('TP009','BO003',1)					
							--  
INSERT INTO PurchaseDetail	--  1
VALUES ('TP010','BO007',4)					

INSERT INTO PurchaseDetail --  10
VALUES ('TP011','BO009',17)					

INSERT INTO PurchaseDetail --  9
VALUES ('TP012','BO005',16)					
							--  
INSERT INTO PurchaseDetail	--  8
VALUES ('TP013','BO010',9)					
							--  
INSERT INTO PurchaseDetail	--  7
VALUES ('TP013','BO002',13)					
							--  
INSERT INTO PurchaseDetail	--  6
VALUES ('TP013','BO006',3)					
							--  
INSERT INTO PurchaseDetail	--  5
VALUES ('TP014','BO008',12)					
							--  
INSERT INTO PurchaseDetail	--  4
VALUES ('TP014','BO009',19)					
							--  
INSERT INTO PurchaseDetail	--  3
VALUES ('TP015','BO003',10)					
							--  
INSERT INTO PurchaseDetail	--  2
VALUES ('TP015','BO005',12)					
							--  
INSERT INTO PurchaseDetail	--  1
VALUES ('TP015','BO007',14)					

--SELECT * FROM Customer
--SELECT * FROM Staff
--SELECT * FROM BoatType
--SELECT * FROM Boat
--SELECT * FROM Supplier
--SELECT * FROM RentTransaction 
--SELECT * FROM RentDetail
--SELECT * FROM PurchaseTransaction
--SELECT * FROM PurchaseDetail