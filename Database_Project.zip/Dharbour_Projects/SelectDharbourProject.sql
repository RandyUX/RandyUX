USE DHarbour_DBProject

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Num. 1 --
-- Display CustomerID, and Total Rent Transaction 
-- (obtained from count of rent transaction) for every customer whose email 
-- ends with �.co.id� and gender is male. 
-- And sort by Total Boat Rent in ascending order. 

SELECT C.CustID  , COUNT (RT.RentTrID) AS [Total Rent Transaction]
FROM RentTransaction RT
JOIN Customer C ON RT.CustID = C.CustID 
WHERE C.CustEmail LIKE '%.co.id' AND C.CustGen = 'Male'
GROUP BY C.CustID 
ORDER BY COUNT (RT.RentTrID) ASC

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Num. 2 --	
-- Display BoatSupplierName, TransactionDate, and Total Boat Quantity 
-- (obtained from the sum of quantity) for every purchase transaction 
-- which occurs in �March� and Total Boat Quantity is greater than 1.

SELECT Sp.SuppName, PT.PurTransDate, SUM (PD.QtyPurBoat) AS [Total Boat Quantity]
FROM PurchaseTransaction PT JOIN PurchaseDetail PD ON PT.PurchaseTrID = PD.PurchaseTrID 
JOIN Supplier Sp ON PT.SuppID = Sp.SuppID
WHERE MONTH(PT.PurTransDate) = 3 AND PD.QtyPurBoat > 1
GROUP BY  Sp.SuppName, PT.PurTransDate 


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Num. 3 --	
-- Display top 2 data of RentID, CustomerName, StaffName, Total Transaction 
-- (obtained from count of rent transaction), Total Rent Duration (obtained 
-- from the sum of rent duration) for every rent transaction which customer�s 
-- name starts with �Mr.� and Total Rent Duration is more than 6.

SELECT RT.RentTrID, C.CustName, S.StaffName, COUNT(RT.RentTrID) AS [Total Transaction], SUM (RD.DurRentBoat) AS [Rent Duration]  
FROM RentTransaction RT JOIN Customer C ON RT.CustID = C.CustID 
						JOIN Staff S ON RT.StaffID  = S.StaffID 
						JOIN RentDetail RD ON RT.RentTrID = RD.RentTrID 
WHERE C.CustName LIKE 'Mr. %' AND RD.DurRentBoat > 6 
GROUP BY RT.RentTrID , C.CustName , S.StaffName 

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Num. 4 --	
-- Display TransactionDate, CustomerName, StaffName, Total of Rent Duration 
-- (obtained from sum of rent duration), and Maximum Rent Duration (obtained 
-- from the maximum of rent duration) for every transaction which occurs 
-- between 9 AM until 11 AM and staff�s name is more than 10 characters.

SELECT RT.RentTransDate, C.CustName, S.StaffName, SUM(RD.DurRentBoat) AS [Total Rent Duration], MAX(RD.DurRentBoat) AS [Maximum Rent Duration]
FROM RentTransaction RT JOIN Customer C ON RT.CustID = C.CustID 
						JOIN Staff S ON RT.StaffID = S.StaffID 
						JOIN RentDetail RD ON RT.RentTrID = RD.RentTrID 
WHERE DATENAME(HOUR,RT.RentTransDate)>=9 AND DATENAME(HOUR,RT.RentTransDate)<11 AND LEN(S.StaffName )>10
GROUP BY RT.RentTransDate, C.CustName, S.StaffName

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Num. 5 --	
-- Display BoatSuppilerID, StaffName, Quantity (Obtained from quantity and 
-- ends with � boat�) and Date (Obtained from purchase transaction date in 
-- �dd mon yyyy� format) for every transaction which staff�s name only have 
-- 1 word and staff�s salary is lower than the average of all staff�s salary. 
--(alias subquery)

SELECT Sp.SuppID, S.StaffName, CONVERT(VARCHAR(20),PD.QtyPurBoat) + ' Boat' AS Quantity, CONVERT(VARCHAR,PurTransDate,106) AS Date
FROM PurchaseTransaction PT JOIN Staff S ON PT.StaffID = S.StaffID
							JOIN Supplier Sp ON PT.SuppID = Sp.SuppID 
							JOIN PurchaseDetail PD ON PT.PurchaseTrID = PD.PurchaseTrID,  
							(SELECT AverageSal = AVG(StaffSal) FROM Staff) AS AVGSal
WHERE  S.StaffSal  > AVGSal.AverageSal AND (CHARINDEX(' ',S.StaffName,6)=0)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Num. 6 --	
-- Display RentID, TransactionDate, StaffName, and Rent Transaction Duration 
-- (obtained from rent duration and ends with � hour(s)�) for each transaction 
-- done handled by a male staff and the day difference between the current 
-- date and the rent transaction date is greater than the average of the day 
-- difference between rent transaction date and current date of all rent transaction.
-- (alias subquery)

SELECT RT.RentTrID, RT.RentTransDate, S.StaffName, CONVERT(VARCHAR,RD.DurRentBoat) + ' hour(s)' AS 'Rent Transaction Duration' 
FROM RentTransaction RT JOIN Staff S ON RT.StaffID = S.StaffID
						JOIN RentDetail RD ON RD.RentTrID = RT.RentTrID  
						,
						(SELECT AverageDay = AVG(DurRentBoat) FROM RentDetail) AS AVGDay
WHERE RD.DurRentBoat > AVGDay.AverageDay
	AND S.StaffGen = 'Male'
GROUP BY RT.RentTrID, RT.RentTransDate, S.StaffName, RD.DurRentBoat 

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Num. 7 --	
-- Display Boat Type Name (obtained from the first word of BoatTypeName in uppercase 
-- format) and Total Purchase Quantity (obtained for the sum of quantity) for every 
-- purchase transaction which the average of the quantity is lower than all of the 
-- quantity and the sum of quantity is 2.
-- (alias subquery)

SELECT UPPER(LEFT(BT.BoatTypeName,1)) AS 'Boat Type Name', SUM(PD.QtyPurBoat) AS 'Total Purchase Quantity'
FROM PurchaseTransaction PT JOIN PurchaseDetail PD ON PT.PurchaseTrID = PD.PurchaseTrID 
							JOIN Boat B ON PD.BoatID = B.BoatID 
							JOIN BoatType BT ON B.BoatTypeID = BT.BoatTypeID,
							(SELECT AVGQ = AVG(QtyPurBoat) FROM PurchaseDetail) AS AVGQty,
							(SELECT SUMQ = SUM(QtyPurBoat) FROM PurchaseDetail) AS SUMQty  
GROUP BY  BT.BoatTypeName,AVGQty.AVGQ, BT.BoatTypeID, SUMQty.SUMQ
HAVING SUMQty.SUMQ = 2 AND AVGQty.AVGQ <  SUMQty.SUMQ 

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Num. 8 --	
-- Display RentID, StaffName, Transaction Month (obtained from the first 3 letters of
-- month of the rent transaction date), Total Rent Duration (obtained from the sum of 
-- rent duration and ends with � hour(s)�), Average Rent Duration (obtained from 
-- average of rent duration and ends with � hour(s)�) for each transaction which the 
-- rent duration is higher than the average of all rent durations and the transaction 
-- occurred in 2017.
-- (alias subquery)

SELECT
	RD.RentTrID,
	ST.StaffName,
	LEFT(CONVERT(VARCHAR, RT.RentTransDate, 107),3) AS 'Transaction Month',
	CONVERT(VARCHAR,SUM(RD.DurRentBoat)) + ' hour(s)' AS 'Total Rent Duration',
	CONVERT(VARCHAR,AVGD.AVGDur) + ' hour(s)' AS 'Average Rent Duration'
FROM RentDetail RD JOIN RentTransaction RT ON RT.RentTrID = RD.RentTrID JOIN Staff ST ON RT.StaffID = ST.StaffID,
	(
		SELECT AVGDur = AVG(DurRentBoat)
		FROM RentDetail 
	) AS AVGD
WHERE YEAR(rt.RentTransDate) = 2017 
GROUP BY RD.RentTrID, ST.StaffName ,RD.DurRentBoat, RT.RentTransDate, AVGD.AVGDur
HAVING RD.DurRentBoat > AVGD.AVGDur

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Num. 9 --	
-- Create a view named RentTransactionData to display RentID, Date (obtained from the 
-- date of transaction with �dd mon yyyy� format), Total Hours (obtained from the sum 
-- of rent duration), and Total Rent Transaction (obtained from the count of rent 
-- transaction) for each transaction which boat�s rent price is less than 20000000 
-- and Total Hours is greater than 5 hours.
CREATE VIEW RentTransactionData AS 
SELECT RT.RentTrID, CONVERT(VARCHAR,RT.RentTransDate,106) AS 'Date', SUM(RD.DurRentBoat) AS 'Total Hours', COUNT (RT.RentTrID) AS 'Total Rent Transaction'
FROM RentTransaction RT JOIN RentDetail RD ON RT.RentTrID = RD.RentTrID 
						JOIN Boat B ON RD.BoatID = B.BoatID 
GROUP BY RT.RentTrID, B.BoatRentPrice,RT.RentTransDate 
HAVING B.BoatRentPrice < 20000000 AND SUM(RD.DurRentBoat) > 5

SELECT * FROM RentTransactionData
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Num. 10 --	
-- Create a view named PurchaseTransactionData to display Transaction ID (obtained 
-- from replacing �TP� to �PUR�), TransactionDate, BoatSupplierName, Total Quantity 
-- (obtained from sum of quantity), Max Amount of Quantity (obtained from maximum 
-- quantity) for every purchase transaction which Total Quantity is less than 5 and 
-- Max Amount of Quantity is greater than 1.

CREATE VIEW PurchaseTransactionData AS
SELECT REPLACE(PT.PurchaseTrID,'TP','PUR') AS 'Transaction ID', PT.PurTransDate, S.SuppName, SUM(PD.QtyPurBoat) AS 'Total Quantity', MAX(PD.QtyPurBoat) AS 'Max Amount of Quantity'
FROM PurchaseTransaction PT JOIN PurchaseDetail PD ON PT.PurchaseTrID = PD.PurchaseTrID 
							JOIN Supplier S ON PT.SuppID = S.SuppID  
GROUP BY PT.PurchaseTrID, PT.PurTransDate, S.SuppName 
HAVING SUM(PD.QtyPurBoat) < 5 AND MAX(PD.QtyPurBoat) > 1

SELECT * FROM PurchaseTransactionData

--DROP VIEW PurchaseTransactionData
