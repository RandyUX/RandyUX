USE DHarbour_DBProject

SELECT * FROM RentDetail RD JOIN RentTransaction RT ON RT.RentTrID = RD.RentTrID 

BEGIN TRAN
INSERT INTO RentTransaction (RentTrID, StaffID, CustID, RentTransDate)
VALUES ('TR016','ST002','CS005','2019-03-01 09:00:01');
INSERT INTO RentDetail (RentTrID, BoatID, DurRentBoat)
VALUES ('TR016','BO010', 20)
COMMIT

BEGIN TRAN
INSERT INTO RentTransaction (RentTrID, StaffID, CustID, RentTransDate)
VALUES ('TR017','ST003','CS003','2019-03-01 15:00:01');
INSERT INTO RentDetail (RentTrID, BoatID, DurRentBoat)
VALUES ('TR017','BO010', 20)
COMMIT

select * from PurchaseTransaction  
Select * From PurchaseDetail

BEGIN TRAN
INSERT INTO PurchaseTransaction (PurchaseTrID, StaffID, SuppID , PurTransDate)
VALUES ('TP016','ST008','SP010','2019-03-01 14:00:01');
INSERT INTO PurchaseDetail (PurchaseTrID , BoatID, QtyPurBoat)
VALUES ('TP016','BO004', 10)
COMMIT

BEGIN TRAN
INSERT INTO PurchaseTransaction (PurchaseTrID, StaffID, SuppID , PurTransDate)
VALUES ('TP020','ST007','SP007','2019-03-02 12:00:01');
INSERT INTO PurchaseDetail (PurchaseTrID , BoatID, QtyPurBoat)
VALUES ('TP020','BO005', 10)
COMMIT

BEGIN TRAN
INSERT INTO RentTransaction (RentTrID, StaffID, CustID, RentTransDate)
VALUES ('TR018','ST003','CS003','2017-03-01 15:00:01');
INSERT INTO RentDetail (RentTrID, BoatID, DurRentBoat)
VALUES ('TR018','BO010', 20)
COMMIT

BEGIN TRAN
INSERT INTO RentTransaction (RentTrID, StaffID, CustID, RentTransDate)
VALUES ('TR019','ST010','CS007','2017-04-01 12:00:01');
INSERT INTO RentDetail (RentTrID, BoatID, DurRentBoat)
VALUES ('TR019','BO010', 50)
COMMIT


SELECT * FROM RentTransaction

