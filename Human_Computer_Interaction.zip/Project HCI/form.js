var error = document.getElementById('lblError');

function CheckPassword(inputtxt) {
    var passw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
    if(inputtxt.match(passw)) {
        return true;
    }

    else {
        return false;
    }
}

function validate() {
    var name = document.getElementById('txtName').value;
    var email = document.getElementById('txtEmail').value;
    var password = document.getElementById('txtPass').value;
    var phone = document.getElementById('txtPhone').value;
    var male = document.getElementById('rbMale').checked;
    var female = document.getElementById('rbFemale').checked;

    if (name.length < 3) {
        error.innerHTML = "Name must consists of minimal 3 characters";
    }

    else if (email.endsWith('.com') == false) {
        error.innerHTML = "Email must end with '.com'";
    }

    else if (CheckPassword(password) == false) {
        error.innerHTML = "Password must be 6-20 characters and contain at least one lowercase, one uppercase, and one number"
    }

    else if (phone.startsWith("+62") == false) {
        error.innerHTML = "Phone number must start with '+62'"
    }

    else if (male == false && female == false) {
        error.innerHTML = "Must choose gender";
    }

    else {
        error.innerHTML = ""

        alert("Register successful");

        document.getElementById('formRegister').reset();
    }
}

function resetFunc() {
    error.innerHTML = ""
}