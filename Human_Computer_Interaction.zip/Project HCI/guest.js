var error = document.getElementById('lblError');

function validate_guest() {
    var name = document.getElementById('txtName').value;
    var email = document.getElementById('txtEmail').value;

    if (name.length < 3) {
        error.innerHTML = "Name must consists of minimal 3 characters";
    }

    else if (email.endsWith('.com') == false) {
        error.innerHTML = "Email must end with '.com'";
    }

    else {
        error.innerHTML = ""

        alert("Answer submitted succesfully");

        document.getElementById('form_guest').reset();
    }
}