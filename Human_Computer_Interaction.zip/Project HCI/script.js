$('.slider-image').css({
    'width':'800px',
    'height':'150px',   
    'overflow':'hidden',
    'position':'relative',
})

$('.image').css({
    'width':'800px',
    'height':'150px',
    'position':'absolute'
});
$('#2').css({'left':'800px'});
$('#3').css({'left':'1600px'});

var index = 1;
setInterval(function(){
    if (index < 3) {
        $('.image').animate({
            'left':'-=800px'
        }, 1000);
        index++;
    }

    else {
        $('.image').animate({
            'left':'+=1600px'
        }, 1000);
        index = 1;
    }
}, 5000);

$('#prev').click(function(){
    if (index > 1) {
        $('.image').animate({
            'left':'+=800px'
        }, 1000);
        index--;
    }

    else {
        $('.image').animate({
            'left':'-=1600px'
        }, 1000);
        index = 3;
    }
});

$('#next').click(function(){
    if (index < 3) {
        $('.image').animate({
            'left':'-=800px'
        }, 1000);
        index++;
    }

    else {
        $('.image').animate({
            'left':'+=1600px'
        }, 1000);
        index = 1;
    }
});