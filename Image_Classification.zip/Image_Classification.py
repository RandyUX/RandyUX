import cv2
import os
import numpy as np

face_detect_object = cv2.face.LBPHFaceRecognizer_create()
def get_path_list(root_path):
    '''
        To get a list of path directories from root path

        Parameters
        ----------
        root_path : str
            Location of root directory
        
        Returns
        -------
        list
            List containing the names of the sub-directories in the
            root directory
    '''
    path_list = os.listdir(root_path)
    return path_list

def get_class_names(root_path, train_names):
    '''
        To get a list of train images path and a list of image classes id

        Parameters
        ----------
        root_path : str
            Location of images root directory
        train_names : list
            List containing the names of the train sub-directories
        
        Returns
        -------
        list
            List containing all image paths in the train directories
        list
            List containing all image classes id
    '''
    path_list = os.listdir(root_path)
    image_label_list = []
    image_list = []

    for i, name in enumerate(path_list):
        image_folder = os.listdir(root_path + '/' + name)
        
        for image in image_folder:
            image_full_path = root_path + '/' + name + '/' + image
            image_list.append(image_full_path)
            image_label_list.append(i)

    return image_list, image_label_list

def get_train_images_data(image_path_list):
    '''
        To load a list of train images from given path list

        Parameters
        ----------
        image_path_list : list
            List containing all image paths in the train directories
        
        Returns
        -------
        list
            List containing all loaded train images
    '''
    image_data_list = []

    for image_path in image_path_list:
        img_read = cv2.imread(image_path)

        image_data_list.append(img_read)

    return image_data_list

def detect_faces_and_filter(image_list, image_classes_list=None):
    '''
        To detect a face from given image list and filter it if the face on
        the given image is more or less than one

        Parameters
        ----------
        image_list : list
            List containing all loaded images
        image_classes_list : list, optional
            List containing all image classes id
        
        Returns
        -------
        list
            List containing all filtered and cropped face images in grayscale
        list
            List containing all filtered faces location saved in rectangle
        list
            List containing all filtered image classes id
    '''
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    train_faces = []
    train_pos_size = []
    train_label = []

    for i, image in enumerate(image_list):
        face_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        detected_face = face_cascade.detectMultiScale(face_gray, scaleFactor = 1.2, minNeighbors = 5)

        if len(detected_face) < 1:
            continue

        for face in detected_face:
            x, y, w, h = face
            face_rect = face_gray[y:y+h, x:x+w]
            train_faces.append(face_rect)
            train_pos_size.append((x, y, w, h))
            if (image_classes_list != None):
                train_label.append(image_classes_list[i])

    return train_faces, train_pos_size, train_label

def train(train_face_grays, image_classes_list):
    '''
        To create and train classifier object

        Parameters
        ----------
        train_face_grays : list
            List containing all filtered and cropped face images in grayscale
        image_classes_list : list
            List containing all filtered image classes id
        
        Returns
        -------
        object
            Classifier object after being trained with cropped face images
    '''
    return face_detect_object.train(train_face_grays, np.array(image_classes_list))


def get_test_images_data(test_root_path, image_path_list):
    '''
        To load a list of test images from given path list

        Parameters
        ----------
        test_root_path : str
            Location of images root directory
        image_path_list : list
            List containing all image paths in the test directories
        
        Returns
        -------
        list
            List containing all loaded test images
    '''
    image_data_list = []

    for image_path in test_names:
        image_full_path = test_root_path + '/' + image_path
        img_read = cv2.imread(image_full_path)
        image_data_list.append(img_read)
        
    return image_data_list

def predict(classifier, test_faces_gray):
    '''
        To predict the test image with classifier

        Parameters
        ----------
        classifier : object
            Classifier object after being trained with cropped face images
        train_face_grays : list
            List containing all filtered and cropped face images in grayscale

        Returns
        -------
        list
            List containing all prediction results from given test faces
    '''
    results = []
    for face in test_faces_gray:
        res, _ = face_detect_object.predict(face)
        results.append(res)

    return results

def draw_prediction_results(predict_results, test_image_list, test_faces_rects, train_names):
    '''
        To draw prediction results on the given test images

        Parameters
        ----------
        predict_results : list
            List containing all prediction results from given test faces
        test_image_list : list
            List containing all loaded test images
        test_faces_rects : list
            List containing all filtered faces location saved in rectangle
        train_names : list
            List containing the names of the train sub-directories

        Returns
        -------
        list
            List containing all test images after being drawn with
            prediction result
    '''
    face_text = []
    for i, image in enumerate(test_image_list):
        x, y, w, h = test_faces_rects[i]
        cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 1)
        text = train_names[predict_results[i]]
        face_text.append(cv2.putText(image, text, (x-30, y-10), 0, 0.65, (255, 255, 255)))

    return face_text

def combine_results(predicted_test_image_list):
    '''
        To combine all predicted test image result into one image

        Parameters
        ----------
        predicted_test_image_list : list
            List containing all test images after being drawn with
            prediction result

        Returns
        -------
        ndarray
            Array containing image data after being combined
    '''
    image_stack = np.hstack((predicted_test_image_list[0], predicted_test_image_list[1]))
    for i in range(2, len(predicted_test_image_list)):
        if (i <= len(predicted_test_image_list) - 1):
            image_stack = np.hstack((image_stack, predicted_test_image_list[i]))

    return image_stack

def show_result(image):
    '''
        To show the given image

        Parameters
        ----------
        image : ndarray
            Array containing image data
    '''
    cv2.imshow("Result", image)
    cv2.waitKey(0)
'''
You may modify the code below if it's marked between

-------------------
Modifiable
-------------------

and

-------------------
End of modifiable
-------------------
'''
if __name__ == "__main__":
    '''
        Please modify train_root_path value according to the location of
        your data train root directory

        -------------------
        Modifiable
        -------------------
    '''
    train_root_path = "dataset/train"
    '''
        -------------------
        End of modifiable
        -------------------
    '''
    
    train_names = get_path_list(train_root_path)
    image_path_list, image_classes_list = get_class_names(train_root_path, train_names)
    train_image_list = get_train_images_data(image_path_list)
    train_face_grays, _, filtered_classes_list = detect_faces_and_filter(train_image_list, image_classes_list)
    classifier = train(train_face_grays, filtered_classes_list)

    '''
        Please modify test_image_path value according to the location of
        your data test root directory

        -------------------
        Modifiable
        -------------------
    '''
    test_root_path = "dataset/test"
    '''
        -------------------
        End of modifiable
        -------------------
    '''

    test_names = get_path_list(test_root_path)
    test_image_list = get_test_images_data(test_root_path, test_names)
    test_faces_gray, test_faces_rects, _ = detect_faces_and_filter(test_image_list)
    predict_results = predict(classifier, test_faces_gray)
    predicted_test_image_list = draw_prediction_results(predict_results, test_image_list, test_faces_rects, train_names)
    final_image_result = combine_results(predicted_test_image_list)
    show_result(final_image_result)