# Core Packages
# ada beberapa import yang kita pakai
import tkinter as tk 
from tkinter import *
from tkinter import ttk
from tkinter.scrolledtext import *
import tkinter.filedialog
import time
time_str = time.strftime("%Y%m%d_%H%M%S")

# NLP Pkg
# ini adalah package untuk menampung inputan paragraphs tsb
from spacy_summarization import text_summarizer
from nltk_summarization import nltk_summarizer

# Web Scrapping Pkg
from bs4 import BeautifulSoup
from urllib.request import urlopen

window = tk.Tk()
window.title("Text Summaryzer")
# window.geometry('1000x600')

HEIGHT = 680
WIDTH = 1000
cvs = tk.Canvas(window, height=HEIGHT, width=WIDTH)
cvs.pack()

frame = tk.Frame(window)
frame.place(relx=0.1, rely=0.1, relwidth=0.8, relheight=0.8)

# Style
style = ttk.Style(window)
style.configure('centertab.TNotebook')

# Tabs 
tab_control = ttk.Notebook(frame,style='centertab.TNotebook')

tab1 = tk.Frame(tab_control, bg='lightblue')
tab_control.add(tab1,text=f' {"HOME":^20s}')
tab_control.pack(expand=True, fill='both')

###########################################################################################################
#########                  FUNCTION      TAB      1       MAIN        HOME                        #########
###########################################################################################################

# Functions
def get_summary():
	raw_text = entry_data.get('1.0',tk.END)
	final_text = nltk_summarizer(raw_text)
	final_text1 = text_summarizer(final_text)
	# final_text1 = remove_punctuation(final_text)
	print(final_text1)
	result = 'Summary: {}\n'.format(final_text1)
	entry_data1.insert(tk.END,result)

def save_summary():
	raw_text = entry_data.get('1.0',tk.END)
	final_text = nltk_summarizer(raw_text)
	final_text1 = text_summarizer(final_text)
	file_name = 'result/textsummary_' + time_str + '.txt'
	with open(file_name,'w') as f:
		f.write(final_text1)
	result = '\nName of File: {} ,\nSummary: {}'.format(file_name,final_text1)
	entry_data1.insert(tk.END,result)

def clear_text():
	entry_data.delete('1.0',END)

def clear_display_result():
	entry_data1.delete('1.0',END)

def close():
	exit(0)

# dibagian function get_summary kemudian akan dilanjutkan di bagian summarizationnya

###########################################################################################################
#########                  TAB           1           MAIN            HOME
###########################################################################################################

# Label
text1 = Label(tab1,text='INPUT TEXT : ',width=12,bg='#fff',fg='#000')
text1.grid(row=3,column=0,padx=0,pady=12)

text2 = Label(tab1,text='RESULT SUMMARIZE : ',width=20,bg='#fff',fg='#000')
text2.grid(row=6,column=9,padx=0,pady=12)

# entry text (ScrollText)
entry_data = ScrolledText(tab1,height=10,width=95)
entry_data.grid(row=5,column=0,columnspan=10,padx=10,pady=10)

# result text summarize (ScrollText)
entry_data1 = ScrolledText(tab1,height=10,width=95)
entry_data1.grid(row=11,column=0,columnspan=10,padx=10,pady=10)

# Buttons Reset
button1 = Button(tab1,text='Reset',
command=clear_text,width=12,bg='#25d366',fg='#fff')
button1.grid(row=6,column=0,padx=10,pady=10)

# Buttons Summarize
button2 = Button(tab1,text='Summarize',
command=get_summary,width=12,bg='#03A9F4',fg='#fff')
button2.grid(row=6,column=1,padx=10,pady=10)

# Buttons Clear Result
button3 = Button(tab1,text='Clear Result',
command=clear_display_result,width=12,bg='#03A9F4',fg='#fff')
button3.grid(row=12,column=0,padx=10,pady=10)

# Buttons Save
button4 = Button(tab1,text='Save',
command=save_summary,width=12,bg='#cd201f',fg='#fff')
button4.grid(row=12,column=1,padx=10,pady=10)

# Buttons Close
button5 = Button(tab1,text='Close',
bg='#000',width=12,fg='#fff',command=close)
button5.grid(row=12,column=9,padx=10,pady=10)

window.mainloop()