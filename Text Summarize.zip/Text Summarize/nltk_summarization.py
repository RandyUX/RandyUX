import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
import heapq  

def nltk_summarizer(raw_text): # inputan yang tadi bakalan di panggil ke fungsi ini
	stopWords = set(stopwords.words("english")) 
	word_frequencies = {}  #untuk tampungin sebuah kata
	for word in nltk.word_tokenize(raw_text): #cek di kalimat yang diinput kemudian ditokenize
	    if word not in stopWords: #validasi jika kata tidak memiliki karakter2 maka 
	        if word not in word_frequencies.keys():
	            word_frequencies[word] = 1 #dalam kondisi tidak ada frekuensi kata 
				# maka indeks frekuensi kata = 1
	        else:
	            word_frequencies[word] += 1#sebaliknya

	maximum_frequncy = max(word_frequencies.values())
	# kemudian dia mengambil frekuensi kata 
	# yang valuenya lebih besar

	for word in word_frequencies.keys():  #pengulangan 
	    word_frequencies[word] = (word_frequencies[word]/maximum_frequncy)

	sentence_list = nltk.sent_tokenize(raw_text)
	# variable untuk menampung sebuah kalimat yang sudah ditokenize
	sentence_scores = {} 
	#penampung dictionary untuk menampung kalimat baru 

	for sent in sentence_list:  #looping si sentence
	    for word in nltk.word_tokenize(sent.lower()):# bagian ini kita tokenize sentence tsb dan kita lower case 
	        if word in word_frequencies.keys(): # kondisi frekuensi kata 
	            if len(sent.split(' ')) < 20: # mengembalikan daftar string setelah melanggar string yg diberikan oleh pemisah yg ditentukan 
	                if sent not in sentence_scores.keys():
	                    sentence_scores[sent] = word_frequencies[word]
	                else:
	                    sentence_scores[sent] += word_frequencies[word]

	summary_sentences = heapq.nlargest(7, sentence_scores, key=sentence_scores.get) 
	# heapq.nlargest() -> menentukan fungsi dari 1 argumen untuk mengekstrak key perbandingan dari setiap elemen 

	summary = ' '.join(summary_sentences)  
	return summary