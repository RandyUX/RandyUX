import string

def remove_punctuation(value):
    result = ""
    for c in value:
        if c not in string.punctuation:
            result += c
        elif 
    return result 